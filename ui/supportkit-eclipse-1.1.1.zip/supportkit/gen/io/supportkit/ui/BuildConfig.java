/** Automatically generated file. DO NOT MODIFY */
package io.supportkit.ui;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}